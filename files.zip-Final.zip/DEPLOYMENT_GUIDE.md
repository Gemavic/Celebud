# CelebUD — Round 3: Domain Fix, Real Slugs, Push Notifications

## 1. Domain canonicalization

**What I changed:** `cloudflare-workers.js` now enforces a single canonical
host before anything else runs (before caching, before prerendering).
Any request to `www.celebud.com` (or plain `http://`) gets a `301`
redirect to `https://celebud.com` with the same path and query preserved.

I picked **`celebud.com` (no www)** as canonical because that's what your
existing `<link rel="canonical">`, `og:url`, and sitemap already use — so
this required no other changes. If you'd rather standardize on
`www.celebud.com` instead, it's a one-line swap
(`CANONICAL_HOST = 'www.celebud.com'`) — just also update the canonical/OG
tags in `index.html` and `SITE_URL` in the two Supabase functions to match,
so every part of the stack agrees.

**Deploy:** redeploy the Worker (`wrangler deploy`). No DNS changes
needed — your `wrangler.toml` route (`*celebud.com/*`) already covers both
`www` and apex, so this Worker now intercepts and redirects both
correctly.

**Verify:**
```
curl -I https://www.celebud.com/some-path
```
You should see `HTTP/1.1 301` with a `Location: https://celebud.com/some-path` header.

---

## 2. Real, readable article slugs

Your `media_content` table already had an unused `slug` column — this
wires it in without breaking any existing link.

- **`src/App.tsx`** — added `/article/:id/:slug` as a second route
  alongside the existing `/article/:id`. Old bare-id links (backlinks,
  bookmarks, anything already indexed) keep working exactly as before.
- **`src/utils/articleUrl.ts`** (new) — builds `/article/<id>/<slug>`,
  falling back to slugifying the title if `slug` is empty.
- **`src/pages/ArticleDetail.tsx`** — self-heals: if someone lands on the
  bare-id URL or a stale slug, it quietly upgrades the address bar to the
  canonical slugged URL via `navigate(..., { replace: true })` — no
  redirect flash, no duplicate-content risk, and the article id (the real
  lookup key) never changes.
- **`MediaCard.tsx`** and **`Hero.tsx`** — your two highest-traffic link
  sources (homepage cards and the hero) now generate slugged links
  directly.
- **`supabase/functions/generate-sitemap`** and **`prerender`** — both
  updated to use the same slugged URLs, so the sitemap, prerendered bot
  pages, and real user URLs all agree on one canonical form per article.

I intentionally left secondary/internal links (admin dashboards, related
articles in the sidebar, editorial page) pointing at bare IDs — they
still resolve correctly via the route above, and touching every single
`Link` in the admin surface wasn't worth the risk for zero SEO benefit.

**Deploy:** ship the frontend changes as part of your normal build/deploy,
and redeploy the two edge functions:
```
supabase functions deploy generate-sitemap
supabase functions deploy prerender
```

---

## 3. Push notifications for breaking news

This is a full working system, not a stub — you can send a real push
notification today once it's deployed.

### What's new
- **`supabase/migrations/20260709000000_add_push_subscriptions.sql`** — a
  `push_subscriptions` table (endpoint + keys per subscriber, optional
  category preference), RLS matching your existing conventions.
- **`src/hooks/usePushNotifications.ts`** — handles permission requests,
  subscribing/unsubscribing via the Push API, and saving the subscription
  to Supabase.
- **`src/components/NotificationButton.tsx`** — a bell icon for the
  header (wired into `Header.tsx` already) plus an optional larger
  opt-in card you can drop anywhere (e.g. homepage) via
  `<NotificationOptInCard />`.
- **`sw.js`** — added `push` and `notificationclick` handlers (cache
  version bumped to `v5` so the update actually takes effect for
  existing visitors).
- **`supabase/functions/send-push-notification`** — sends the actual
  push using the standard `web-push` library (correct VAPID +
  encryption handling — this is genuinely not something to hand-roll).
- **`src/pages/ArticleManagement.tsx`** — added a **"Notify" button**
  next to each article's existing Share button. Click it to push that
  article's title/description/image to all subscribers (or just
  subscribers of that article's category, if they set a preference).

### Setup steps (required before this works)

1. **Add the VAPID keys.** I generated a real key pair for you — see
   `VAPID_KEYS.txt`. Treat the private key like a password.
   - Frontend: add to your `.env` (and your host's environment variables):
     ```
     VITE_VAPID_PUBLIC_KEY=<the VITE_VAPID_PUBLIC_KEY value from VAPID_KEYS.txt>
     ```
   - Backend: in Supabase Dashboard → Edge Functions → Secrets, add:
     ```
     VAPID_PUBLIC_KEY=<same public key>
     VAPID_PRIVATE_KEY=<the private key from VAPID_KEYS.txt>
     VAPID_SUBJECT=mailto:you@celebud.com
     ```

2. **Run the migration:**
   ```
   supabase db push
   ```

3. **Deploy the new edge function:**
   ```
   supabase functions deploy send-push-notification
   ```

4. **Rebuild and deploy the frontend** as usual — the bell icon will
   appear in the header automatically (it renders nothing on browsers
   that don't support Web Push, e.g. iOS Safari outside an installed
   PWA).

5. **Test it:** visit the site, click the bell, accept the browser
   permission prompt, then go to `/admin/articles` and click "Notify" on
   any article. You should get a real notification within a couple of
   seconds — click it and it opens straight to that article.

### One judgment call worth knowing about
Right now "Notify" is a manual button an editor clicks per article —
that was the safer default rather than auto-firing on every publish
(you don't want a notification storm on routine content, only real
breaking news). If you'd rather have it fire automatically for articles
marked `is_featured` or above a certain priority, that's a small addition
to the publish flow — say the word and I'll wire it in.
